# 🧠 Data Structures & Algorithms Notes

## Week 1: Arrays & Strings
- Array basics: fixed size, index-based access
- Common problems:
  - Two Sum
  - Maximum Subarray (Kadane’s Algorithm)
- Tips:
  - Always check edge cases (empty array, 1 element)
  - Practice sliding window with fixed and dynamic window sizes

## Week 2: Hash Maps & Sets
- Use cases:
  - Counting frequency
  - Removing duplicates
- Common problems:
  - Group Anagrams
  - Longest Substring Without Repeating Characters

## Patterns Mastered
- ✅ Two Pointers
- ⬜️ Sliding Window
- ⬜️ Binary Search

---

### ✍️ Notes
> Use `defaultdict` or `Counter` in Python for quick frequency maps.
> In JavaScript, use `Map` instead of plain objects for consistent key behavior.
