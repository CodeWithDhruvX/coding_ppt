# 🧩 Design Patterns Cheatsheet

## 1. Singleton
- Ensures a class has only one instance
- Example: Config loader, DB connection

## 2. Factory
- Creates objects without exposing instantiation logic
- Good for switching implementations easily

## 3. Observer
- One-to-many dependency
- Used in event systems (e.g., Redux, EventEmitter)

## 4. Dependency Injection
- Pass dependencies through constructor/function
- Promotes testability and decoupling
