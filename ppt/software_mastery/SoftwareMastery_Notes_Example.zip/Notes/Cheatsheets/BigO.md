# ⏱️ Big-O Complexity Cheatsheet

| Operation | Array | Linked List | HashMap |
|-----------|-------|-------------|---------|
| Access    | O(1)  | O(n)        | N/A     |
| Search    | O(n)  | O(n)        | O(1)    |
| Insert    | O(n)  | O(1)        | O(1)    |
| Delete    | O(n)  | O(1)        | O(1)    |

### Common Complexities
- Constant: O(1)
- Logarithmic: O(log n)
- Linear: O(n)
- Quadratic: O(n^2)
- Exponential: O(2^n)
