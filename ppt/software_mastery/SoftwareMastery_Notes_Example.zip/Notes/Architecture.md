# 🏗️ Software Architecture Notes

## Week 1: MVC Pattern
- Model: Business logic
- View: UI layer (HTML/CSS/Frontend)
- Controller: Handles request/response and coordinates Model/View

📝 Example:
- Express.js:
  - Route → Controller → Service (Model) → Response

## Week 2: Layered Architecture
- Layers:
  - Presentation
  - Business Logic
  - Data Access
  - Database
- Benefits:
  - Separation of concerns
  - Easier testing and maintenance

## Tools:
- Mermaid.js for quick diagrams
- Draw C4 diagrams using Structurizr Lite

---

### 💡 Tips
> Keep dependencies flowing **inward**. Core business logic should not import frameworks or infrastructure.
